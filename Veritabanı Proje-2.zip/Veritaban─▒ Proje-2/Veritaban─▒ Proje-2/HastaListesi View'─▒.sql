CREATE VIEW HastaListesi
AS 
SELECT hasta_id , hasta_tc , hasta_adı , hasta_soyadı , hasta_yaş , hasta_erkek_mi
FROM hasta