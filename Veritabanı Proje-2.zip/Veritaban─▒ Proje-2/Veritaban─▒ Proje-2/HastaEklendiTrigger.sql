DROP TRIGGER IF EXISTS HastaEklendiTrigger;

DELIMITER //

CREATE TRIGGER HastaEklendiTrigger BEFORE INSERT ON hasta
FOR EACH ROW
BEGIN
    INSERT INTO log (mesaj) VALUES (CONCAT(NEW.hasta_adı, ' ', NEW.hasta_soyadı, ' isimli hasta eklendi'));
END;
//

DELIMITER ;
